try:
    from FAdo.reex import *
    from FAdo.codes import *
    from FAdo.fio import *
    import base64
except:
    exit()
print "\nREQUEST:\ndecide whether the given language satisfies the given property. If no, return a witness; else return Nones."
print "\nANSWER:\n",
ax = "QE5GQSAyDQowIGEgMQ0KMSBiIDINCjIgYSAyDQoyIGIgMg0KDQpATkZBIDINCjAgYSAxDQoxIEBlcHNpbG9uIDMNCjMgYiAyDQoyIGEgMg0KMiBiIDINCg=="
a = readOneFromString(base64.b64decode(ax))
ssigma = a.Sigma
p = buildPrefixProperty(ssigma)
answer = p.notSatisfiesW(a)
print answer
raw_input('\nPress <enter> to quit.')
