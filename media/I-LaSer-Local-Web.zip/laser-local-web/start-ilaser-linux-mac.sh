if !([ -d ./ilaser ] && [ -f ./ilaser/bin/activate ]); then
echo 'Installing I-LaSer. This may take a few minutes.'
python3 -m virtualenv ilaser -q
source ./ilaser/bin/activate
#'--quiet' must be repeated or else the notice that 'pip needs an update' shows up
pip3 install -r requirements.txt --quiet --quiet --no-deps
#FAdo has a lot of 'dependencies' that are never imported or used. I've picked out
#the important dependencies and the possibly important dependencies and add them manually
cp ./prax.py ./ilaser/lib/*/*/FAdo/prax.py
#replace installed prax with modified version
pip3 install django~=5.0.5 --quiet --quiet;
#we do, however, need the Django dependencies
fi
source ./ilaser/bin/activate
cd ./django-files
python3 manage.py runserver $1
deactivate