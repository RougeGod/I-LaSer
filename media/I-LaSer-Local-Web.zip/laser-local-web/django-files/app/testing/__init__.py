"""Contains all the unit tests"""
#pylint:disable=W0401
from app.testing.test_laser_baxter import *
from app.testing.test_laser_program_execution import *
from app.testing.test_data import *
from app.testing.test_laser_ABIS import *
from app.testing.test_laser_gen import *
from app.testing.test_laser import *
from app.testing.test_online_mode import *
from app.testing.test_theta_laser_program_execution import *
from app.testing.test_theta_prop import *
