Requirements: Python 3, version 3.9 or above, with the virtualenv module installed, and approximately 300MB disk space.

To run the I-LaSer web version: run the start-ilaser script (depending on your OS), which will create
a virtual Python environment, switch to this environment, install all required modules,
and run the server. Initial install may take a minute or longer, depending on your Internet speed.
After initial install, the modules will not be reinstalled, which will make starting I-LaSer much faster.

The install script can optionally be given a port number from which to run the server.
If no port number is provided, I-LaSer will run on the default port of 8000.

To run the local server after the virtual environment has been installed, run the install script again,
and go to the website specified by the terminal, which should start with http://127.0.0.1. 
"localhost" can be substituted for 127.0.0.1 in the web browser (i.e. localhost:8000 if running default settings)

To remove the virtual environment, delete the ilaser folder.
This software does not modify system Python packages or registries, so deleting the entire ilaser-local-web
folder is perfectly safe, provided you are not currently in the ilaser Python environment. You will
not be in the ilaser Python environment unless you deliberately entered it, or the web server is currently running.